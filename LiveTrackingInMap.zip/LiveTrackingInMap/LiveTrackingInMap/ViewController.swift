//
//  ViewController.swift
//  LiveTrackingInMap
//
//  Created by Apple on 12/12/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
import GoogleMaps
import GooglePlaces
import Alamofire
import SwiftyJSON

class ViewController: UIViewController {
    @IBOutlet weak var googleView: GMSMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
        configureGoogleMapView()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
extension ViewController: GMSMapViewDelegate {
    func configureGoogleMapView() {
        let camera = GMSCameraPosition.camera(withLatitude: 28.524555, longitude: 77.275111, zoom: 10.0, bearing: 30, viewingAngle: 40)
         //Setting the googleView
         self.googleView.camera = camera
         self.googleView.delegate = self
         self.googleView?.isMyLocationEnabled = true
         self.googleView.settings.myLocationButton = true
         self.googleView.settings.compassButton = true
         self.googleView.settings.zoomGestures = true
         self.googleView.animate(to: camera)
         self.view.addSubview(self.googleView)
         
         //Setting the start and end location
         let origin = "\(28.524555),\(77.275111)"
         let destination = "\(28.643091),\(77.218280)"
         
         let url = "https://maps.googleapis.com/maps/api/directions/json?origin=\(origin)&destination=\(destination)&mode=driving"
        AF.request(url).responseJSON { response in
            print(response.request as Any)  // original URL request
            print(response.response as Any) // HTTP URL response
            print(response.data as Any)     // server data
            print(response.result)   // result of response serialization
            let json = try? JSON(data: response.data!)
            let routes = json?["routes"].arrayValue

            for route in routes!
            {
                let routeOverviewPolyline = route["overview_polyline"].dictionary
                let points = routeOverviewPolyline?["points"]?.stringValue
                let path = GMSPath.init(fromEncodedPath: points!)
                let polyline = GMSPolyline.init(path: path)
                polyline.strokeColor = UIColor.blue
                polyline.strokeWidth = 2
                polyline.map = self.googleView
            }
            
        }
        // Creates a marker in the center of the map.
        let marker = GMSMarker()
        marker.position = CLLocationCoordinate2D(latitude: 28.524555, longitude: 77.275111)
        marker.title = "Mobiloitte"
        marker.snippet = "India"
        marker.map = googleView
        
        //28.643091, 77.218280
        let marker1 = GMSMarker()
        marker1.position = CLLocationCoordinate2D(latitude: 28.643091, longitude: 77.218280)
        marker1.title = "NewDelhi"
        marker1.snippet = "India"
        marker1.map = googleView
        draw()
    }
    func draw() {
            let path = GMSMutablePath()
            path.addLatitude(28.524555, longitude:77.275111) //Mobiloitte
            path.addLatitude(28.643091, longitude:77.218280) // New Delhi
//            path.addLatitude(21.291, longitude:-157.821) // Hawaii
//            path.addLatitude(37.423, longitude:-122.091) // Mountain View
    
            let polyline = GMSPolyline(path: path)
            polyline.strokeColor = .blue
            polyline.strokeWidth = 3.0
            polyline.map = self.googleView
    
    
    }
}

